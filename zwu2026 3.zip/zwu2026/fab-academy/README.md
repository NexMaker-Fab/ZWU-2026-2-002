# Fab Academy 作业提交系统

一个现代化的 Web 工具，用于管理和提交 Fab Academy 课程作业。

## 📁 项目结构

```
fab-academy/
├── index.html          # 首页
├── assignments.html    # 作业列表页面
├── week.html          # Week 详情页面（动态加载）
├── projects.html      # 项目展示页面
├── team.html          # 团队介绍页面
├── styles.css         # 全局样式
└── script.js          # JavaScript 交互逻辑
```

## 🎨 设计规范

### 颜色系统
- **主色（克莱因蓝）**: `#002FA7` - 代表核心逻辑、深度思考与专业稳定性
- **辅助色（拓竹绿）**: `#00AE42` - 代表加工成功、进度正常
- **预警色（珊瑚红）**: `#FF6B6B` - 用于风险提示
- **底色（微光灰）**: `#F8F9FA` - 极简底色
- **文字（深矿黑）**: `#1D1D1F` - 极致阅读对比度

### 组件样式
- **卡片设计**: 24px-30px 超大圆角
- **按钮形态**: 胶囊型按钮
- **图标风格**: 极简线性图标
- **阴影处理**: 扁平化设计，悬停时微调

## 🚀 快速开始

### 方法 1: 直接打开
直接双击 `index.html` 文件即可在浏览器中预览。

### 方法 2: 使用本地服务器（推荐）

#### 使用 Python
```bash
# Python 3
cd fab-academy
python -m http.server 8000
```

然后在浏览器访问：`http://localhost:8000`

#### 使用 Node.js (需要安装)
```bash
npx serve fab-academy
```

## 📱 功能特性

### 导航系统
- **Home**: 首页概览
- **作业**: 二级下拉菜单（Week 1-10）
- **项目**: 作品展示
- **团队介绍**: 成员信息

### 核心功能
1. ✅ 作业状态追踪（已完成/进行中/未开始）
2. ✅ 进度可视化（进度条展示）
3. ✅ 任务清单管理
4. ✅ 作业提交表单
5. ✅ 响应式设计（支持移动端）

## 🌐 页面说明

### 首页 (index.html)
- Hero 欢迎区域
- 快速统计卡片
- 最近作业展示

### 作业列表 (assignments.html)
- 所有 Week 概览
- 状态标签（已完成/进行中/未开始）
- 点击跳转到 Week 详情

### Week 详情 (week.html)
- 动态加载 Week 数据
- 进度条展示
- 任务清单
- 作业提交表单

### 项目展示 (projects.html)
- 项目卡片网格
- 分类筛选按钮
- 状态标识

### 团队介绍 (team.html)
- 团队成员卡片
- 角色和职责
- 个人简介

## 🛠️ 自定义内容

### 修改 Week 数据
编辑 `script.js` 中的 `loadWeekData` 函数：

```javascript
const weekData = {
    1: {
        title: 'Week 1 - 建模与设计',
        description: '学习 CAD 软件基础...',
        status: 'success',
        progress: 100,
        tasks: [...]
    }
};
```

### 修改团队成员
编辑 `team.html` 中的团队卡片内容。

### 修改颜色
编辑 `styles.css` 中的 CSS 变量：

```css
:root {
    --primary: #002FA7;
    --success: #00AE42;
    --danger: #FF6B6B;
    /* ... */
}
```

## 📊 后续优化建议

1. **后端集成**: 添加数据库支持，实现真正的作业提交功能
2. **用户系统**: 添加登录和权限管理
3. **文件上传**: 实现实际的文件上传功能
4. **Wiki 集成**: 与 Fab Academy Wiki 系统集成
5. **通知系统**: 作业截止日期提醒

## 📝 技术栈

- HTML5
- CSS3 (使用 CSS Variables)
- Vanilla JavaScript (ES6+)
- 无第三方依赖

## 🎯 兼容性

- ✅ Chrome / Edge (推荐)
- ✅ Firefox
- ✅ Safari
- ✅ 移动端浏览器

## 📄 许可证

MIT License

---

**Fab Academy 2026** | Made with ❤️ for Digital Fabrication
