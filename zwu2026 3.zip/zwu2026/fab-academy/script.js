// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// Mobile menu toggle
function toggleMenu() {
    const navLinks = document.querySelector('.nav-links');
    navLinks.classList.toggle('active');
}

// Close mobile menu when clicking outside
document.addEventListener('click', function(e) {
    const nav = document.querySelector('.navbar');
    const menuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    
    if (!nav.contains(e.target) && navLinks.classList.contains('active')) {
        navLinks.classList.remove('active');
    }
});

// Dynamic week page loader
function loadWeekData(weekId) {
    const weekData = {
        1: {
            title: 'Week 1 - 建模与设计',
            description: '学习 CAD 软件基础，完成第一个 3D 模型设计',
            status: 'success',
            statusText: '已完成',
            progress: 100,
            tasks: [
                { title: '学习 Fusion 360 基础', desc: '掌握草图绘制和基本建模', completed: true },
                { title: '完成参数化设计练习', desc: '创建可调整尺寸的模型', completed: true },
                { title: '提交 Wiki 文档', desc: '记录学习过程和成果', completed: true }
            ]
        },
        2: {
            title: 'Week 2 - 激光切割',
            description: '掌握激光切割机操作，制作参数化结构',
            status: 'success',
            statusText: '已完成',
            progress: 100,
            tasks: [
                { title: '学习激光切割机操作', desc: '安全培训和设备熟悉', completed: true },
                { title: '设计参数化结构', desc: '使用 Illustrator 或 Inkscape', completed: true },
                { title: '制作实物模型', desc: '切割和组装', completed: true }
            ]
        },
        3: {
            title: 'Week 3 - 数控加工',
            description: '使用 CNC 铣床进行减材制造',
            status: 'danger',
            statusText: '进行中',
            progress: 60,
            tasks: [
                { title: '学习 CNC 编程', desc: 'G-code 基础和 CAM 软件', completed: true },
                { title: '设计加工零件', desc: '考虑刀具路径和材料', completed: true },
                { title: 'CNC 加工实操', desc: '上机操作和设备调试', completed: false },
                { title: '后处理和测量', desc: '表面处理和尺寸检测', completed: false }
            ]
        },
        4: {
            title: 'Week 4 - 3D 打印',
            description: '增材制造工艺与切片软件应用',
            status: '',
            statusText: '未开始',
            progress: 0,
            tasks: [
                { title: '学习 FDM 打印原理', desc: '了解材料和工艺参数', completed: false },
                { title: '切片软件练习', desc: 'Cura 或 PrusaSlicer', completed: false },
                { title: '打印测试模型', desc: '校准和优化打印质量', completed: false }
            ]
        }
    };

    return weekData[weekId] || null;
}

// Initialize week page if on week.html
if (window.location.pathname.includes('week.html')) {
    const urlParams = new URLSearchParams(window.location.search);
    const weekId = parseInt(urlParams.get('id'));
    
    if (weekId) {
        const data = loadWeekData(weekId);
        if (data) {
            document.getElementById('week-title').textContent = data.title;
            document.getElementById('week-description').textContent = data.description;
            
            // Update progress
            document.getElementById('progress-fill').style.width = data.progress + '%';
            document.getElementById('progress-text').textContent = data.progress + '%';
            
            // Update status badge
            const statusBadge = document.getElementById('status-badge');
            statusBadge.textContent = data.statusText;
            if (data.status === 'success') {
                statusBadge.classList.add('status-success');
            } else if (data.status === 'danger') {
                statusBadge.classList.add('status-danger');
            }
            
            // Render tasks
            const taskList = document.getElementById('task-list');
            data.tasks.forEach(task => {
                const taskElement = document.createElement('div');
                taskElement.className = 'task-item';
                taskElement.innerHTML = `
                    <div class="task-checkbox ${task.completed ? 'checked' : ''}"></div>
                    <div class="task-info">
                        <div class="task-title">${task.title}</div>
                        <div class="task-desc">${task.desc}</div>
                    </div>
                `;
                taskList.appendChild(taskElement);
            });
        }
    }
}
